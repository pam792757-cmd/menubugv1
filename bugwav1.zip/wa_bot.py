#!/usr/bin/env python3
# wa_bot.py - Bot WhatsApp untuk auto kirim pesan
# Jalankan terpisah: python wa_bot.py --target "628123456789" --message "HALO" --repeat 50

import pyautogui
import pyperclip
import time
import argparse
import sys
import webbrowser

def main():
    parser = argparse.ArgumentParser(description='WA Bot untuk bom chat')
    parser.add_argument('--target', help='Nomor target (contoh: 628123456789)')
    parser.add_argument('--message', help='Pesan yang mau dikirim')
    parser.add_argument('--repeat', type=int, default=10, help='Jumlah pengiriman')
    parser.add_argument('--delay', type=float, default=0.5, help='Jeda antar pesan (detik)')
    
    args = parser.parse_args()
    
    if not args.message:
        print("❌ Error: Message wajib diisi")
        sys.exit(1)
    
    print("""
    ╔══════════════════════════════════════╗
    ║   REU WA BOT - AUTOMATED SENDER      ║
    ╚══════════════════════════════════════╝
    """)
    
    print(f"📱 Target : {args.target if args.target else 'MANUAL'}")
    print(f"💬 Message: {args.message[:50]}..." if len(args.message) > 50 else f"💬 Message: {args.message}")
    print(f"🔄 Repeat : {args.repeat}x")
    print(f"⏱️ Delay  : {args.delay}s")
    print()
    
    # Copy message ke clipboard
    pyperclip.copy(args.message)
    print("✅ Message copied to clipboard")
    
    if args.target:
        # Buka WhatsApp Web dengan nomor target
        web_url = f"https://web.whatsapp.com/send?phone={args.target}"
        print(f"🌐 Membuka: {web_url}")
        webbrowser.open(web_url)
        print("⏳ Tunggu 10 detik biar WA Web loading...")
        time.sleep(10)
    else:
        input("👉 Pastikan WA Web terbuka & chat target dipilih. Tekan Enter...")
    
    print("🚀 Mulai mengirim...")
    
    for i in range(args.repeat):
        # Paste
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(0.2)
        
        # Enter
        pyautogui.press('enter')
        
        print(f"   ✅ Pesan ke-{i+1} terkirim")
        time.sleep(args.delay)
    
    print("\n🎉 Selesai! Semua pesan terkirim.")

if __name__ == '__main__':
    main()